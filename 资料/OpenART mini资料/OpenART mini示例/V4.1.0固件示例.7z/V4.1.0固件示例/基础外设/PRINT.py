
import sensor, image, time

# print函数中的内容可以输出到OpenMV IDE的同时也会通过调试串口输出(调试串口接线方式：C8接到USB转TTL的RX，C9接到USB转TTL的TX)

a = 20
print("hello word")
print("a = %d" % (a))# 打印一个变量的值 十进制输出
print("a = %x" % (a))# 打印一个变量的值 十六进制输出
while(True):
    pass
